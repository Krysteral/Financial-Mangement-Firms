<?php 
//Add beginning code to 
//1. Require the needed 3 files
require_once("session.php");
require_once("included_functions.php");
require_once("database.php");
///////////////////////////////////////////////////////////////////////////////////
//  Step 9  -  invoke verify_login
//				Will redirect to index_<yourLastName>.php if there is not a SESSION admin set
//				**************** NOTE:  REPLACE <yourLastName> with your last name
//				****************        Also include the semester in the filename as noted in the instructions
ini_set("display_errors", 1);
error_reporting(E_ALL);

///////////////////////////////////////////////////////////////////////////////////

//2. Connect to your database
new_header("Delete from Top 40 Songs Administrators"); 
$mysqli = Database::dbConnect();
$mysqli -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//3. Output a message, if there is one
if (($output = message()) !== null) {
    echo $output;
}


///////////////////////////////////////////////////////////////////////////////////
// Step 5.  Get this admins ID and delete from the database
    $id = $_GET['id'];
    $delete = $mysqli -> prepare("DELETE FROM admins WHERE id =?");
    $stmt = $delete -> execute([$id]);

// Execute query and create a session message
// If successful (i.e., $stmt is true), output "Successfully deleted user"
// If unsuccessful, output "Unable to delete user"
    if($stmt){
        $_SESSION['message'] = "Successfully deleted user";
    } else{
        $_SESSION['message'] = "Unable to delete user";
    }
//////////////////////////////////////////////////////////////////////////////////




redirect("addLoginS24.php");	
	
//Define footer with the phrase "Top 40 Songs"
//Disconnect from database database
new_footer("Top 40 Songs");
Database::dbDisconnect($mysqli);
?>