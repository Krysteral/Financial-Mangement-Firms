<?php 
//Add beginning code to 
//1. Require the needed 3 files
require_once("session.php");
require_once("included_functions.php");
require_once("database.php");
///////////////////////////////////////////////////////////////////////////////////
//  Step 9  -  invoke verify_login
//				Will redirect to index_<yourLastName>.php if there is not a SESSION admin set
//				**************** NOTE:  REPLACE <yourLastName> with your last name
//				****************        Also include the semester in the filename as noted in the instructions
verify_login();
/////////////////////////////////////////////////////////////////////////////////// 
ini_set("display_errors", 1);
	error_reporting(E_ALL);
//2. Connect to your database
$mysqli = Database::dbConnect();
$mysqli -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
new_header("Top 40 Songs Admin"); 
//3. Check if there is an output message.  NOTE that this is given and is BELOW Step 9.

//Output a message, if there is one
	if (($output = message()) !== null) {
		echo $output;
	}

	  
	  
///////////////////////////////////////////////////////////////////////////////////////////////
//  Step 4.  Check to see if form submitted username and password text boxes are filled in.
//           If it has, verify username and password have been set and are not empty fields
if(isset($_POST['submit'])){
	if((isset($_POST['username']) && $_POST['username'] !== "") && (isset($_POST['password']) && $_POST['password'] !== "")){
	    //Grab posted values for username and password, encrypting the password
		//so that it is set up to compare with the encrypted password in the database
		//Use password_encrypt
		$username = $_POST['username'];
		$password = $_POST['password'];
		$hash = password_encrypt($password);
		
		
		//Query database for this "new" username. Be sure to limit 1 in your SQL as there should only be one.
		$verify = $mysqli->prepare("SELECT id, username FROM admins WHERE username = ?");
		$verify->execute([$username]);
		$count = $verify -> rowCount();
		
		
		//If the username DOES exist in table, create a session message - "The username already exists"
		//Reidrect back to addLogin.php
		if($count != 0){
			$_SESSION['message'] = "The username already exists.";
			redirect("addLoginS24.php");
		} 
		//If the username DOES NOT exist in table, insert into table
		//Verify stmt successfully executes by using an if-statement
		// If successful, create a session message - "User successfully added"
		// If NOT successful, create a session message - "Could not add user"
		//In both cases, redirect back to addLogin.php
		else {
			$insert = $mysqli->prepare("INSERT INTO admins(username, hashed_password) VALUES (?, ?)");
			$stmt1 = $insert->execute([$username, $hash]);
			if($stmt1){
				$_SESSION['message'] = "User successfully added";
			} else{
				$_SESSION['message'] = "Could not add user";
			}
			redirect("addLoginS24.php");
		}
	} else {
		$_SESSION['message'] = "Must enter username and password";
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////
?>
		
		<div class='row'>
		<label for='left-label' class='left inline'>

		<h3>Add Top 40 Song Administrator</h3>

<!--//////////////////////////////////////////////////////////////////////////////////////////////// -->
<!--    Step 2. Create a form with textboxes for adding both a username and password -->
	<form action="addLoginS24.php" method="post">
		<p>Username:<input type="text" name="username" value="" /></p>
		<p>Password:<input type="password" name="password" value="" /></p>
		<input type="submit" name="submit" value="Add Adminstrator" />
	</form>

	
	
	
<!--///////////////////////////////////////////////////////////////////////////////////////////////// -->


			<p><br /><br /><hr />
			<h3>Current Top 40 Adminstrators</h3>

<!--//////////////////////////////////////////////////////////////////////////////////////////////// -->
<!--    Step 3. Display current Administrators.  Also provide a red X using the red_x_icon.jpg in front of each row that allows you to delete; you will need to size.  ALSO add the onclick option to verify delete -->
<!--            the username from your database This requires including the id# in the query string -->
		<?php
			$adminQ = $mysqli->prepare("SELECT id, username FROM admins");
			$stmt = $adminQ->execute();
			if($stmt){
				echo "<div class='row'>";
				echo "<center>";
				echo "<table>";
				echo "<thead>";
				echo "<tr><td></td><td>Name</td>";
				echo "</thead>";
				echo "<tbody>";
				while($row = $adminQ->fetch(PDO::FETCH_ASSOC)){
				echo "<tr>";
				echo "<td> &nbsp; <a href='deleteLoginS24.php?id=".urlencode($row['id'])."' onclick='return confirm(\"Are you sure you want to delete?');\"> <img src='red_x_icon.jpg' width='15' height='15'> </a></td>";
				echo "<td>".$row['username']."</td>";
				echo "</tr>";
				}
				echo "</tbody>";
				echo "</table>";
				echo "</center>";
				echo "</div>";
	
			}
		?>
		

			

<!--//////////////////////////////////////////////////////////////////////////////////////////////// -->
			
  	  <?php echo "<br /><p>&laquo:<a href='readS24.php'>Back to Main Page</a>"; ?>
			
	</div>
	</label>

<?php 
//Define footer with the phrase "Top 40 Songs"
//Disconnect from database database
new_footer("Top 40 Songs");
Database::dbDisconnect($mysqli);

?>