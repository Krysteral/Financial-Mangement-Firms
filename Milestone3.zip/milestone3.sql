-- Option 2: Kien and Visho

-- Query 1 (Visho): 
SELECT InvestmentTypes.TypeName, 
AVG(Investments.AmountInvested) AS AverageInvested
FROM Investments NATURAL JOIN InvestmentTypes
GROUP BY InvestmentTypes.TypeName
ORDER BY InvestmentTypes.TypeName;

-- Query 2 (Kien): 
SELECT *
FROM Investments
WHERE Investments.UserID IN (
SELECT Users.UserID FROM Users
WHERE Users.UserID IN (
SELECT Accounts.UserID 
FROM Accounts NATURAL JOIN AccountTypes 
WHERE AccountTypes.TypeName = 'Checking' AND Accounts.InstitutionName = 'Bank A'));


-- Kien's query 3: for each User's 'FName LName' (use concat to list together),
-- list all transaction descriptions on one line. List users' 'FName LName' once 
-- with many transaction.description - use group concat.
SELECT CONCAT(Users.FName, ' ', Users.LName) AS User,
GROUP_CONCAT(Transactions.Description SEPARATOR ', ') AS TransactionDes
FROM Users NATURAL JOIN Accounts NATURAL JOIN Transactions 
GROUP BY Users.UserID ORDER BY Users.LName, Users.FName;

-- Visho's query 3: for each Category.Name list all 'Fname Lname' (use concat to list both names).
-- List one Transaction.description with many Users 'Fname Lname'
SELECT Categories.Name AS CategoryName,
Transactions.Description AS TransactionDescription,
GROUP_CONCAT(DISTINCT CONCAT(Users.FName, ' ', Users.LName) 
ORDER BY Users.FName, Users.LName SEPARATOR ', ') AS User
FROM Categories
NATURAL JOIN Users
NATURAL JOIN Transactions 
NATURAL JOIN Accounts
GROUP BY Categories.CategoryID, Transactions.Description
ORDER BY Categories.Name, Transactions.Description;

