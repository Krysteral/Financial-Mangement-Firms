INSERT INTO Users (UserID, FName, LName, Email, PasswordHash, RegistrationDate) VALUES 
(1, 'John', 'Doe', 'john.doe@example.com', 'hashed_password_123', '2024-01-01 00:00:00'),
(2, 'Jane', 'Smith', 'jane.smith@example.com', 'hashed_password_456', '2024-01-02 00:00:00'),
(3, 'Alice', 'Johnson', 'alice.johnson@example.com', 'hashed_password_789', '2024-01-03 00:00:00'),
(4, 'Bob', 'Brown', 'bob.brown@example.com', 'hashed_password_101', '2024-01-04 00:00:00'),
(5, 'Charlie', 'Green', 'charlie.green@example.com', 'hashed_password_202', '2024-01-05 00:00:00'),
(6, 'Diana', 'Prince', 'diana.prince@example.com', 'hashed_password_303', '2024-01-06 00:00:00'),
(7, 'Evan', 'Wright', 'evan.wright@example.com', 'hashed_password_404', '2024-01-07 00:00:00'),
(8, 'Fiona', 'Gallagher', 'fiona.gallagher@example.com', 'hashed_password_505', '2024-01-08 00:00:00'),
(9, 'George', 'King', 'george.king@example.com', 'hashed_password_606', '2024-01-09 00:00:00'),
(10, 'Hannah', 'Abbott', 'hannah.abbott@example.com', 'hashed_password_707', '2024-01-10 00:00:00');

INSERT INTO AccountTypes (AccountTypeID, TypeName) VALUES 
(1, 'Checking'),
(2, 'Savings'),
(3, 'Investment'),
(4, 'Retirement');

INSERT INTO Accounts (AccountID, UserID, AccountTypeID, InstitutionName, Balance, Currency) VALUES 
(1, 1, 1, 'Bank A', 1000.00, 'USD'),
(2, 2, 2, 'Bank B', 5000.00, 'USD'),
(3, 3, 3, 'Broker C', 20000.00, 'USD'),
(4, 4, 4, 'Broker D', 15000.00, 'EUR'),
(5, 5, 1, 'Bank E', 2500.00, 'GBP'),
(6, 6, 2, 'Bank F', 6000.00, 'USD'),
(7, 7, 3, 'Broker G', 10000.00, 'EUR'),
(8, 8, 4, 'Broker H', 20000.00, 'USD'),
(9, 9, 1, 'Bank I', 3500.00, 'EUR'),
(10, 10, 2, 'Bank J', 4500.00, 'GBP');

INSERT INTO CategoryType (TypeID, TypeName) VALUES 
(1, 'Expense'),
(2, 'Income');

INSERT INTO Categories (CategoryID, Name, TypeID) VALUES 
(1, 'Groceries', 1),
(2, 'Income', 2),
(3, 'Electronics', 1),
(4, 'Utilities', 1),
(5, 'Gifts', 2),
(6, 'Online Subscriptions', 1),
(7, 'Books', 2),
(8, 'Car Maintenance', 1),
(9, 'Consulting', 2),
(10, 'Dining', 1);

INSERT INTO Transactions (TransactionID, AccountID, Date, Amount, CategoryID, Description) VALUES 
(1, 1, '2024-01-01 10:00:00', 100.00, 1, 'Grocery Shopping'),
(2, 2, '2024-01-02 12:00:00', 150.00, 2, 'Freelance Payment'),
(3, 1, '2024-01-03 14:30:00', 200.00, 3, 'Electronics'),
(4, 3, '2024-01-04 09:20:00', 50.00, 4, 'Utilities'),
(5, 5, '2024-01-05 16:45:00', 75.00, 5, 'Gift'),
(6, 4, '2024-02-01 11:00:00', 120.00, 2, 'Online Subscription'),
(7, 6, '2024-02-02 15:30:00', 90.00, 3, 'Book Sale'),
(8, 7, '2024-02-03 10:25:00', 210.00, 1, 'Car Maintenance'),
(9, 8, '2024-02-04 12:45:00', 300.00, 4, 'Consulting Fee'),
(10, 10, '2024-02-05 17:00:00', 160.00, 5, 'Dining Out');

INSERT INTO InvestmentTypes (InvestmentTypeID, TypeName) VALUES 
(1, 'Stocks'),
(2, 'Bonds'),
(3, 'Real Estate'),
(4, 'Cryptocurrency');

INSERT INTO Investments (InvestmentID, UserID, AmountInvested, CurrentValue, DatePurchased, InvestmentTypeID) VALUES 
(1, 1, 5000.00, 5500.00, '2023-01-01', 1),
(2, 2, 10000.00, 10200.00, '2023-02-01', 2),
(3, 3, 15000.00, 15200.00, '2023-03-01', 3),
(4, 4, 2000.00, 2100.00, '2023-04-01', 4),
(5, 5, 3000.00, 3200.00, '2023-05-01', 2),
(6, 6, 1000.00, 1200.00, '2023-06-01', 1),
(7, 7, 4000.00, 4100.00, '2023-07-01', 3),
(8, 8, 500.00, 550.00, '2023-08-01', 2),
(9, 9, 6000.00, 6100.00, '2023-09-01', 2),
(10, 10, 200.00, 250.00, '2023-10-01', 1);

INSERT INTO Budgets (BudgetID, UserID, Amount, StartDate, EndDate) VALUES 
(1, 1, 300.00, '2024-01-01', '2024-01-31'),
(2, 2, 200.00, '2024-01-01', '2024-01-31'),
(3, 3, 500.00, '2024-01-01', '2024-01-31'),
(4, 4, 150.00, '2024-01-01', '2024-01-31'),
(5, 5, 250.00, '2024-01-01', '2024-01-31'),
(6, 6, 400.00, '2024-02-01', '2024-02-28'),
(7, 7, 350.00, '2024-02-01', '2024-02-28'),
(8, 8, 220.00, '2024-02-01', '2024-02-28'),
(9, 9, 180.00, '2024-02-01', '2024-02-28'),
(10, 10, 260.00, '2024-02-01', '2024-02-28');

INSERT INTO SavingsGoals (GoalID, UserID, Name, TargetAmount, CurrentAmount, TargetDate) VALUES 
(1, 1, 'Vacation', 2000.00, 500.00, '2025-12-31'),
(2, 2, 'Emergency Fund', 5000.00, 1000.00, '2024-12-31'),
(3, 3, 'Home Down Payment', 20000.00, 3000.00, '2026-12-31'),
(4, 4, 'Car Replacement', 15000.00, 2500.00, '2025-06-30'),
(5, 5, 'Education Fund', 10000.00, 2000.00, '2027-08-31'),
(6, 6, 'Retirement', 50000.00, 4000.00, '2030-12-31'),
(7, 7, 'Wedding', 10000.00, 1500.00, '2024-07-31'),
(8, 8, 'Business Startup', 30000.00, 5000.00, '2025-01-31'),
(9, 9, 'Technology Upgrade', 5000.00, 1200.00, '2024-11-30'),
(10, 10, 'Charity Fund', 2000.00, 300.00, '2024-12-31');
